java disassembler $1
